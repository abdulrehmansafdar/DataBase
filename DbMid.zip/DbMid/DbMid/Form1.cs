﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DbMid
{
    public partial class Form1 : Form
    {
        private SqlConnection conn;
        private TabControl tabControl1; // Correct type declaration
        public int StudentID;
        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=DESKTOP-54IBTRP\\SQLEXPRESS;Initial Catalog=DBLabProject;Integrated Security=True;");
            tabControl1 = new TabControl();
            tabControl1.SuspendLayout();
            panel1.Dock = DockStyle.Fill;


        }

       
       
        private void Form1_Load(object sender, EventArgs e)
        {
            GetStudentsRecord();

        }
        private void GetStudentsRecord()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            if (conn.State == ConnectionState.Open)
            {
                using (SqlCommand cmd = new SqlCommand("Select * from StudentData", conn))
                {
                    DataTable dt = new DataTable();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    StudentRecord.DataSource = null;
                    StudentRecord.DataSource = dt;
                }
            }

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
            if (isValid())
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    string statusValue = checkBox1.Checked ? "Active" : "Passive"; // Check the checkbox state
                                                                                   // Check the checkbox state
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO StudentData (FirstName, LastName, RegistrationNumber, Contact, Email,Status) VALUES (@FirstName, @LastName, @RegistrationNumber, @Contact,@Email, @Status)", conn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@FirstName", txtStudentName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLast.Text);
                        cmd.Parameters.AddWithValue("@RegistrationNumber", txtRegno.Text);
                        cmd.Parameters.AddWithValue("@Email", txtAdress.Text);
                        cmd.Parameters.AddWithValue("@Contact", txtPhone.Text);
                        cmd.Parameters.AddWithValue("@Status", statusValue); // Assign the value based on checkbox state

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student added successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        GetStudentsRecord();
                    }
                }
                else
                {
                    MessageBox.Show("Failed to open database connection.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private bool isValid()
        {
            if (txtStudentName.Text == string.Empty)
            {
                MessageBox.Show("Student name is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

       




       
        

       
        private void StudentDataR(object sender, DataGridViewCellEventArgs e)
        {
            StudentID = Convert.ToInt32(StudentRecord.SelectedRows[0].Cells[0].Value);
            txtStudentName.Text = StudentRecord.SelectedRows[0].Cells[1].Value.ToString();
            txtLast.Text = StudentRecord.SelectedRows[0].Cells[2].Value.ToString();
            txtRegno.Text = StudentRecord.SelectedRows[0].Cells[3].Value.ToString();
            txtAdress.Text = StudentRecord.SelectedRows[0].Cells[5].Value.ToString();
            txtPhone.Text = StudentRecord.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void StudentRecord_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            // Your button2_Click logic
            tabControl1.SelectedIndex = 1;
            if (StudentID > 0)
            {
                SqlCommand cmd = new SqlCommand("Update StudentData SET FirstName=@FirstName,LastName=@LastName,RegistrationNumber=@RegistrationNumber,Contact=@Contact,Email=@Email Where StudentID=@ID", conn);

                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@FirstName", txtStudentName.Text);
                cmd.Parameters.AddWithValue("@LastName", txtLast.Text);

                cmd.Parameters.AddWithValue("@RegistrationNumber", txtRegno.Text);
                cmd.Parameters.AddWithValue("@Email", txtAdress.Text);
                cmd.Parameters.AddWithValue("@Contact", txtPhone.Text);
                cmd.Parameters.AddWithValue("@ID", this.StudentID);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Student updated successfully", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();

            }
            else
            {
                MessageBox.Show("Please select student", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Your button3_Click logic
            tabControl1.SelectedIndex = 2;
            if (StudentID > 0)
            {
                SqlCommand cmd = new SqlCommand("Delete From StudentData  Where StudentID=@ID", conn);

                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@ID", this.StudentID);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Student Deleted successfully", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();
            }
            else
            {
                MessageBox.Show("Please select some student", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            txtStudentName.Clear();

            txtRegno.Clear();
            txtAdress.Clear();
            txtPhone.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CLOForm c = new CLOForm();
            c.TopLevel = false;
            c.FormBorderStyle = FormBorderStyle.None;
            c.Dock = DockStyle.Fill;

            // Clear existing controls from the panel
           
            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(c);
            c.Show();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Rubric r = new Rubric();
            r.TopLevel = false;
            r.FormBorderStyle = FormBorderStyle.None;
            r.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(r);
            r.Show();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void panelside_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtLast_TextChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Assessment c = new Assessment();
            c.TopLevel = false;
            c.FormBorderStyle = FormBorderStyle.None;
            c.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(c);
            c.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            Attendence a = new Attendence();
            a.TopLevel = false;
            a.FormBorderStyle = FormBorderStyle.None;
            a.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(a);
            a.Show();
        }
    }
}
