﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DbMid
{
    public partial class Rubric : Form
    {
        private SqlConnection conn;
        private TabControl tabControl1; // Correct type declaration
        public int RId;
        public Rubric()
        {
            InitializeComponent();
            conn = new SqlConnection("Data Source=DESKTOP-54IBTRP\\SQLEXPRESS;Initial Catalog=DBLabProject;Integrated Security=True;");
            tabControl1 = new TabControl();
            tabControl1.SuspendLayout();
        }

        private void Rubric_Load(object sender, EventArgs e)
        {
            GetStudentsRecord();
        }
        private void GetStudentsRecord()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            if (conn.State == ConnectionState.Open)
            {
                using (SqlCommand cmd = new SqlCommand("Select * from RubricTable", conn))
                {
                    DataTable dt = new DataTable();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        dt.Load(dr);
                    }

                    StudentRecord.DataSource = null;
                    StudentRecord.DataSource = dt;
                }
            }

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                if (conn.State == ConnectionState.Open)
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO RubricTable VALUES (@RubricID,@Details,@MeasurementLevel)", conn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@RubricID", txtRubricId.Text);

                        cmd.Parameters.AddWithValue("@Details", txtDetails.Text);
                        cmd.Parameters.AddWithValue("@MeasurementLevel", txtLevel.Text);


                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Student added successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        GetStudentsRecord();
                    }
                }
                else
                {
                    MessageBox.Show("Failed to open database connection.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        private bool isValid()
        {
            if (txtRubricId.Text == string.Empty)
            {
                MessageBox.Show("RubricID  is required", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (RId > 0) // Checking if RId is greater than 0
            {
                SqlCommand cmd = new SqlCommand("Update RubricTable SET RubricID=@RubricID, Details=@Details, MeasurementLevel=@MeasurementLevel WHERE ID=@ID", conn);

                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@RubricID", txtRubricId.Text);
                cmd.Parameters.AddWithValue("@Details", txtDetails.Text);
                cmd.Parameters.AddWithValue("@MeasurementLevel", txtLevel.Text);
                cmd.Parameters.AddWithValue("@ID", RId); // Use RId directly as the parameter value

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Rubric updated successfully", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();
            }
            else
            {
                MessageBox.Show("Please select Rubric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (RId > 0)
            {
                SqlCommand cmd = new SqlCommand("Delete From RubricTable  Where ID=@ID", conn);

                cmd.CommandType = CommandType.Text;

                cmd.Parameters.AddWithValue("@ID", this.RId);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Rubric Deleted successfully", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetStudentsRecord();
            }
            else
            {
                MessageBox.Show("Please select some Rubric", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtRubricId.Clear();

            txtDetails.Clear();
            txtLevel.Clear();
        }

        private void StudentDataR(object sender, DataGridViewCellEventArgs e)
        {
            RId = Convert.ToInt32(StudentRecord.SelectedRows[0].Cells[0].Value);
            txtRubricId.Text = StudentRecord.SelectedRows[0].Cells[1].Value.ToString();

            txtDetails.Text = StudentRecord.SelectedRows[0].Cells[2].Value.ToString();
            txtLevel.Text = StudentRecord.SelectedRows[0].Cells[3].Value.ToString();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 c = new Form1();
            c.TopLevel = false;
            c.FormBorderStyle = FormBorderStyle.None;
            c.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(c);
            c.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            CLOForm c = new CLOForm();
            c.TopLevel = false;
            c.FormBorderStyle = FormBorderStyle.None;
            c.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(c);
            c.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Assessment c = new Assessment();
            c.TopLevel = false;
            c.FormBorderStyle = FormBorderStyle.None;
            c.Dock = DockStyle.Fill;

            // Clear existing controls from the panel

            panel1.Controls.Clear();

            // Add CLOForm to the panel
            panel1.Controls.Add(c);
            c.Show();
        }
    }
}
